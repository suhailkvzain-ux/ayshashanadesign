AYSHASHANA DESIGN WEBSITE

Stack: Next.js + Supabase
Supabase project: ayshashana-design

Implemented:
- Premium/minimal portfolio pages
- Supabase public content loading
- Projects with multiple images
- Renders and drawings galleries
- Admin login using Supabase Auth
- Admin project/render/drawing uploads
- Publish/unpublish fields
- Protected admin database/storage policies
- Public WhatsApp CTA: +971503916796

Setup:
1. npm install
2. npm run dev
3. Open /admin and sign in with the admin account.

IMPORTANT ADMIN STEP:
The Supabase database intentionally has no admin user yet. After the first Supabase Auth user is created, add that user's UUID to public.admin_users using the Supabase SQL editor. Do not expose a service-role key in the browser.

Environment variables are in .env.local for this project.
