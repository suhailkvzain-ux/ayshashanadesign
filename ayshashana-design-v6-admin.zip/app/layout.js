import './globals.css';
export const metadata={title:'Aysha Shana Design | Interior Design · 3D · CAD',description:'Dubai interior design, 3D visualization, photorealistic rendering and CAD services.'};
export default function RootLayout({children}){return <html lang="en"><body>{children}</body></html>}
