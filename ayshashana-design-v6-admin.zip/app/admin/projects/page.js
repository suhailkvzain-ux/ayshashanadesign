import Manager from '../Manager'; export default function Page(){return <Manager kind="projects"/>}
