'use client';
import {useEffect,useState} from 'react';
import Link from 'next/link';
import {SUPABASE_URL,SUPABASE_KEY,supabaseFetch,publicImage} from '../../lib/supabase';
import {getSession} from '../../lib/auth';

const TITLES={projects:'Projects',renders:'3D Renders',drawings:'Drawings'};
const EMPTY={title:'',slug:'',category:'',location:'',year:'',description:'',published:true,sort_order:0,project_id:''};
const MAX=10*1024*1024, ACCEPT='image/jpeg,image/png,image/webp,image/avif';
const slugify=s=>s.toLowerCase().trim().replace(/[^a-z0-9]+/g,'-').replace(/^-+|-+$/g,'');

async function tok(){const s=await getSession();if(!s)throw new Error('Session expired. Please sign in again.');return s.access_token}
async function db(path,opts={}){return supabaseFetch(`/rest/v1/${path}`,{...opts,token:await tok()})}
async function upload(file,bucket){
  if(file.size>MAX)throw new Error(`${file.name} is over 10 MB — please compress it first.`);
  const path=`${crypto.randomUUID()}.${(file.name.split('.').pop()||'jpg').toLowerCase()}`;
  const r=await fetch(`${SUPABASE_URL}/storage/v1/object/${bucket}/${path}`,{method:'POST',headers:{apikey:SUPABASE_KEY,Authorization:`Bearer ${await tok()}`,'Content-Type':file.type},body:file});
  if(!r.ok)throw new Error(await r.text());
  return path;
}
async function unstore(bucket,path){ // best effort — never blocks the delete
  try{await fetch(`${SUPABASE_URL}/storage/v1/object/${bucket}/${path}`,{method:'DELETE',headers:{apikey:SUPABASE_KEY,Authorization:`Bearer ${await tok()}`}})}catch{}
}

export default function Manager({kind}){
  const isP=kind==='projects';
  const [state,setState]=useState('loading'),[err,setErr]=useState(''),[msg,setMsg]=useState(''),[busy,setBusy]=useState('');
  const [items,setItems]=useState([]),[imgs,setImgs]=useState([]),[projects,setProjects]=useState([]);
  const [form,setForm]=useState(EMPTY),[files,setFiles]=useState([]),[open,setOpen]=useState(null);
  const change=(k,v)=>setForm(f=>({...f,[k]:v}));

  async function load(){
    const [x,pr]=await Promise.all([db(`${kind}?select=*&order=sort_order.asc,created_at.desc`),isP?null:db('projects?select=id,title&order=title.asc')]);
    setItems(x||[]);if(pr)setProjects(pr);
    if(isP)setImgs(await db('project_images?select=*&order=sort_order.asc,created_at.asc')||[]);
  }
  useEffect(()=>{(async()=>{
    try{
      if(!await getSession())return setState('signin');
      const a=await db('admin_users?select=user_id&limit=1');
      if(!a?.length){setErr('This account is signed in but has not been added to the admin list yet.');return setState('denied')}
      await load();setState('ok');
    }catch(e){setErr(e.message);setState('denied')}
  })()},[]);

  async function run(label,fn){setBusy(label);setErr('');setMsg('');try{await fn();await load()}catch(e){setErr(e.message)}finally{setBusy('')}}

  function create(e){
    e.preventDefault();const formEl=e.currentTarget;
    run('create',async()=>{
      if(!files.length)throw new Error('Please select at least one image.');
      if(!isP&&!form.project_id)throw new Error('Please choose which project these belong to.');
      const paths=[];for(const f of files)paths.push(await upload(f,kind));
      if(isP){
        const [p]=await db('projects',{method:'POST',headers:{Prefer:'return=representation'},body:{title:form.title,slug:form.slug||slugify(form.title),category:form.category,location:form.location,year:form.year?Number(form.year):null,description:form.description,published:form.published,sort_order:Number(form.sort_order)||0,cover_image:paths[0]}});
        await db('project_images',{method:'POST',body:paths.map((storage_path,i)=>({project_id:p.id,storage_path,sort_order:i}))});
      }else{
        await db(kind,{method:'POST',body:paths.map((storage_path,i)=>({title:form.title?(files.length>1?`${form.title} ${i+1}`:form.title):files[i].name.replace(/\.[^.]+$/,''),storage_path,published:form.published,sort_order:(Number(form.sort_order)||0)+i,project_id:form.project_id}))});
      }
      setForm(EMPTY);setFiles([]);formEl.reset();setMsg(`Saved — ${paths.length} image(s) uploaded.`);
    });
  }
  const addImages=(p,list)=>run('add'+p.id,async()=>{
    if(!list.length)return;
    const mine=imgs.filter(i=>i.project_id===p.id),start=mine.length?Math.max(...mine.map(i=>i.sort_order||0))+1:0;
    const paths=[];for(const f of list)paths.push(await upload(f,'projects'));
    await db('project_images',{method:'POST',body:paths.map((storage_path,i)=>({project_id:p.id,storage_path,sort_order:start+i}))});
    if(!p.cover_image)await db(`projects?id=eq.${p.id}`,{method:'PATCH',body:{cover_image:paths[0]}});
    setMsg(`${paths.length} image(s) added to ${p.title}.`);setOpen(p.id);
  });
  const setCover=(p,i)=>run('cover'+i.id,async()=>{await db(`projects?id=eq.${p.id}`,{method:'PATCH',body:{cover_image:i.storage_path}});setMsg('Cover image updated.')});
  const removeImage=(p,i)=>confirm('Remove this image from the project?')&&run('img'+i.id,async()=>{
    await db(`project_images?id=eq.${i.id}`,{method:'DELETE'});await unstore('projects',i.storage_path);
    if(p.cover_image===i.storage_path){const next=imgs.find(x=>x.project_id===p.id&&x.id!==i.id);await db(`projects?id=eq.${p.id}`,{method:'PATCH',body:{cover_image:next?.storage_path||null}})}
    setMsg('Image removed.');
  });
  const toggle=it=>run('pub'+it.id,async()=>{await db(`${kind}?id=eq.${it.id}`,{method:'PATCH',body:{published:!it.published}});setMsg(it.published?'Hidden from the website.':'Now live on the website.')});
  const remove=it=>confirm(isP?`Delete "${it.title}" and all its project images? This cannot be undone.`:'Delete this image?')&&run('del'+it.id,async()=>{
    if(isP){
      const mine=imgs.filter(i=>i.project_id===it.id);
      await db(`project_images?project_id=eq.${it.id}`,{method:'DELETE'});
      await db(`projects?id=eq.${it.id}`,{method:'DELETE'});
      for(const i of mine)await unstore('projects',i.storage_path);
    }else{await db(`${kind}?id=eq.${it.id}`,{method:'DELETE'});await unstore(kind,it.storage_path)}
    setMsg('Deleted.');
  });

  if(state==='loading')return <main className="admin"><div className="adminbox"><p>Loading…</p></div></main>;
  if(state==='signin')return <main className="admin"><div className="adminbox"><h1>Sign in required</h1><Link href="/admin">Go to admin login →</Link></div></main>;
  if(state==='denied')return <main className="admin"><div className="adminbox"><Link href="/admin">← Dashboard</Link><h1 style={{marginTop:40}}>Admin access not enabled</h1><p>{err}</p></div></main>;

  return <main className="admin"><div className="adminbox">
    <Link href="/admin">← Dashboard</Link>
    <div className="adminnav" style={{marginTop:25}}>{Object.keys(TITLES).map(k=><Link key={k} href={`/admin/${k}`} style={{fontWeight:k===kind?700:400}}>{TITLES[k]}</Link>)}</div>
    <div className="eyebrow">CONTENT MANAGER</div><h1>{TITLES[kind]}</h1>

    <h2 style={{marginTop:35,fontSize:18}}>{isP?'Add a new project':`Upload ${TITLES[kind].toLowerCase()}`}</h2>
    <form className="form" onSubmit={create}>
      {isP?<>
        <input placeholder="Project title" value={form.title} onChange={e=>change('title',e.target.value)} required/>
        <input placeholder="URL slug (auto-filled from title if empty)" value={form.slug} onChange={e=>change('slug',e.target.value)}/>
        <input placeholder="Category e.g. Residential Interior" value={form.category} onChange={e=>change('category',e.target.value)}/>
        <input placeholder="Location" value={form.location} onChange={e=>change('location',e.target.value)}/>
        <input placeholder="Year" type="number" value={form.year} onChange={e=>change('year',e.target.value)}/>
        <textarea placeholder="Description" rows="5" value={form.description} onChange={e=>change('description',e.target.value)}/>
      </>:<>
        <label>Related project
          <select value={form.project_id} onChange={e=>change('project_id',e.target.value)} required>
            <option value="">Select a project</option>{projects.map(p=><option key={p.id} value={p.id}>{p.title}</option>)}
          </select></label>
        <input placeholder="Title (optional — file name is used if empty)" value={form.title} onChange={e=>change('title',e.target.value)}/>
      </>}
      <label>Images (JPG, PNG, WEBP · max 10 MB each){isP&&' — the first one becomes the cover'}
        <input type="file" accept={ACCEPT} multiple onChange={e=>setFiles(Array.from(e.target.files||[]))}/></label>
      {files.length>0&&<div className="am-thumbs">{files.map((f,i)=><img key={i} className="am-img" src={URL.createObjectURL(f)} alt=""/>)}</div>}
      <label><input type="checkbox" checked={form.published} onChange={e=>change('published',e.target.checked)}/> Publish immediately</label>
      <input type="number" placeholder="Sort order (lower shows first)" value={form.sort_order} onChange={e=>change('sort_order',e.target.value)}/>
      <button disabled={!!busy}>{busy==='create'?'UPLOADING…':'SAVE & UPLOAD'}</button>
    </form>
    {msg&&<div className="success">{msg}</div>}{err&&<div className="error">{err}</div>}

    <h2 style={{marginTop:50,fontSize:18}}>Existing {TITLES[kind].toLowerCase()} ({items.length})</h2>
    <div className="am-list">{items.length===0&&<p className="formhint">Nothing uploaded yet.</p>}
    {items.map(it=>{
      const mine=isP?imgs.filter(i=>i.project_id===it.id):[];
      const thumb=publicImage(isP?'projects':kind,isP?it.cover_image:it.storage_path);
      return <div className="am-card" key={it.id}>
        {thumb?<img className="am-cover" src={thumb} alt=""/>:<div className="am-cover"/>}
        <div>
          <strong>{it.title}</strong>
          <div className="formhint">{isP?`/${it.slug} · ${mine.length} image(s) · `:`${projects.find(p=>p.id===it.project_id)?.title||'Unassigned'} · `}{it.published?'Live':'Hidden'}</div>
          <div className="am-actions">
            {isP&&<label className="am-btn">+ Add images<input hidden type="file" accept={ACCEPT} multiple onChange={e=>{const l=Array.from(e.target.files||[]);e.target.value='';addImages(it,l)}}/></label>}
            {isP&&<button onClick={()=>setOpen(open===it.id?null:it.id)}>{open===it.id?'Hide images':'Manage images'}</button>}
            <button disabled={!!busy} onClick={()=>toggle(it)}>{it.published?'Unpublish':'Publish'}</button>
            <button disabled={!!busy} onClick={()=>remove(it)}>Delete</button>
            {busy==='add'+it.id&&<span className="formhint">Uploading…</span>}
          </div>
          {isP&&open===it.id&&<div className="am-thumbs">{mine.map(i=><figure key={i.id}>
            <img className="am-img" src={publicImage('projects',i.storage_path)} alt=""/>
            <div className="am-actions">{it.cover_image===i.storage_path?<span className="formhint">Cover</span>:<button onClick={()=>setCover(it,i)}>Set cover</button>}<button onClick={()=>removeImage(it,i)}>Remove</button></div>
          </figure>)}</div>}
        </div>
      </div>})}
    </div>
  </div></main>;
}
