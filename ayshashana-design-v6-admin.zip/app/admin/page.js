'use client';
import {useEffect,useState} from 'react';
import Link from 'next/link';
import {supabaseFetch} from '../../lib/supabase';
import {getSession,saveSession} from '../../lib/auth';
export default function Admin(){const [session,setSession]=useState(null),[email,setEmail]=useState(''),[password,setPassword]=useState(''),[error,setError]=useState(''),[busy,setBusy]=useState(false);
useEffect(()=>{getSession().then(s=>s&&setSession(s))},[]);
async function login(e){e.preventDefault();setBusy(true);setError('');try{const x=await supabaseFetch('/auth/v1/token?grant_type=password',{method:'POST',body:{email,password}});setSession(saveSession(x))}catch(err){setError(err.message)}finally{setBusy(false)}}
function logout(){localStorage.removeItem('aysha_session');setSession(null)}
if(session)return <main className="admin"><div className="adminbox"><div className="eyebrow">AYSHASHANA DESIGN</div><h1>Admin Dashboard</h1><p>Signed in as {session.user?.email}</p><div className="adminnav"><Link className="btn dark" href="/admin/projects">PROJECTS</Link><Link className="btn" href="/admin/renders">RENDERS</Link><Link className="btn" href="/admin/drawings">DRAWINGS</Link><button className="btn" onClick={logout}>SIGN OUT</button></div><p>Upload and manage your portfolio without editing website code.</p></div></main>;
return <main className="admin"><div className="adminbox"><div className="eyebrow">PRIVATE ADMIN</div><h1>Sign in</h1><p>Use the admin account created for your website.</p><form className="form" onSubmit={login}><input type="email" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} required/><input type="password" placeholder="Password" value={password} onChange={e=>setPassword(e.target.value)} required/><button disabled={busy}>{busy?'SIGNING IN…':'SIGN IN'}</button></form>{error&&<div className="error">{error}</div>}</div></main>}
