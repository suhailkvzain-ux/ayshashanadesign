import Link from 'next/link';
import {notFound} from 'next/navigation';
import {Nav,WhatsApp,Footer} from '../../components';
import {fallbackProjects} from '../../data';
import {publicQuery,publicImage} from '../../../lib/supabase';

const wa='https://wa.me/971503916796?text=Hi%20Aysha%20Shana%20Design%2C%20I%20found%20your%20website%20and%20I%E2%80%99m%20interested%20in%20your%20interior%20design%20services.%20I%E2%80%99d%20like%20to%20discuss%20my%20project%20and%20get%20a%20quote.';

async function getProject(slug){
  try{
    const p=await publicQuery('projects',`select=*&slug=eq.${encodeURIComponent(slug)}&published=eq.true`);
    return p?.[0]||fallbackProjects.find(x=>x.slug===slug);
  }catch{return fallbackProjects.find(x=>x.slug===slug)}
}

async function getRelated(projectId){
  if(!projectId)return {imgs:[],renders:[],drawings:[]};
  try{
    const [imgs,renders,drawings]=await Promise.all([
      publicQuery('project_images',`select=*&project_id=eq.${projectId}&order=sort_order.asc,created_at.asc`),
      publicQuery('renders',`select=*&project_id=eq.${projectId}&published=eq.true&order=sort_order.asc,created_at.asc`),
      publicQuery('drawings',`select=*&project_id=eq.${projectId}&published=eq.true&order=sort_order.asc,created_at.asc`)
    ]);
    return {
      imgs:(imgs||[]).map(i=>publicImage('projects',i.storage_path)),
      renders:(renders||[]).map(i=>({src:publicImage('renders',i.storage_path),title:i.title})),
      drawings:(drawings||[]).map(i=>({src:publicImage('drawings',i.storage_path),title:i.title}))
    };
  }catch{return {imgs:[],renders:[],drawings:[]}}
}

export default async function Project({params}){
  const { slug } = await params;
  const p=await getProject(slug);if(!p)notFound();
  const related=await getRelated(p.id);
  const cover=p.image||publicImage('projects',p.cover_image);
  return <><Nav/><main>
    <section className="projectHero"><div className="eyebrow">{p.category||p.type} {p.location?'· '+p.location:''}</div><img src={cover} alt={p.title}/></section>
    <section className="projectBody"><div><h1>{p.title}</h1></div><div><p>{p.description||p.desc}</p>{p.year&&<p>{p.year}</p>}<a className="btn dark" href={wa} target="_blank" rel="noreferrer">ENQUIRE ABOUT A PROJECT →</a></div></section>

    {related.imgs.length>0&&<section className="section projectSection"><div className="sectionhead"><h2>Project Images</h2></div><div className="projectGallery">{related.imgs.map((x,i)=><img key={i} src={x} alt={`${p.title} project image ${i+1}`}/>)}</div></section>}
    {related.renders.length>0&&<section className="section projectSection"><div className="sectionhead"><h2>3D Renders</h2><Link className="muted" href="/renders">VIEW ALL RENDERS →</Link></div><div className="projectGallery">{related.renders.map((x,i)=><figure key={i}><img src={x.src} alt={x.title||`${p.title} render ${i+1}`}/>{x.title&&<figcaption className="cardsmall">{x.title}</figcaption>}</figure>)}</div></section>}
    {related.drawings.length>0&&<section className="section projectSection"><div className="sectionhead"><h2>Technical Drawings</h2><Link className="muted" href="/drawings">VIEW ALL DRAWINGS →</Link></div><div className="projectGallery">{related.drawings.map((x,i)=><figure key={i}><img src={x.src} alt={x.title||`${p.title} drawing ${i+1}`}/>{x.title&&<figcaption className="cardsmall">{x.title}</figcaption>}</figure>)}</div></section>}

    <section className="projectNav"><Link href="/projects">← ALL PROJECTS</Link><a href={wa} target="_blank" rel="noreferrer">WHATSAPP FOR A QUOTE →</a></section>
  </main><WhatsApp/><Footer/></>;
}
